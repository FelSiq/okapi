package generalOkapiPack;

/**
* Implements stuff common to all Okapi general classes.
*/
public class GeneralOkapi {
	// It's empty by purpose.
}